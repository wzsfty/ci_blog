/**
 * Created by BYM on 2016/7/21.
 */

// 初始化导航信息

$(".button-collapse").sideNav();
$('.button-collapse').click(function () {
    $('.side-nav').css('left','0%');
});
// weber.pub
var _hmt = _hmt || [];
(function() {
    var hm = document.createElement("script");
    hm.src = "//hm.baidu.com/hm.js?21e84bab8a9685ddee15fda30a812860";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
})();
// vuejs.pub
var _hmt = _hmt || [];
(function() {
    var hm = document.createElement("script");
    hm.src = "//hm.baidu.com/hm.js?a6e211e094a3c37f3cc335193a574802";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
})();
// babyli.wang
var _hmt = _hmt || [];
(function() {
    var hm = document.createElement("script");
    hm.src = "//hm.baidu.com/hm.js?a12aa47962b81f71c9f0d5aea07bef82";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
})();